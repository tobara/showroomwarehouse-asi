# ShowroomWarehouse ASI (CI-ready)

This repository contains a ready-to-build Visual Studio solution for a GTA V ASI plugin.
It is configured to use the included `sdk/` directory (ScriptHookV SDK).

## Local build (Windows)
- Install **Visual Studio 2022 Build Tools** with **MSVC v143** and **Windows 10 SDK**.
- Open `ShowroomWarehouse_ASI/ShowroomWarehouse_ASI.sln` and build **Release | x64**.
- The built `.asi` will be produced at `ShowroomWarehouse_ASI/x64/Release/ShowroomWarehouse.asi`.

## CI build (GitHub Actions)
Pushing this repo to GitHub will trigger the included workflow to build on Windows and publish the `.asi` as an artifact.
