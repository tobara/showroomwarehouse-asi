
ShowroomWarehouse — native C++ ASI (ScriptHookV)
================================================

This is a ready-to-build C++ ASI plugin that creates a drive-in showroom/warehouse.
It saves cars parked inside a zone and respawns them so you can walk around them.

Controls (in-game)
------------------
- F10 — Toggle the warehouse visible/hidden
- F9  — Move the warehouse origin to your current position & heading
- E   — Save/update the nearest vehicle at its current spot (must be inside zone)
- DEL — Remove the nearest saved vehicle

Default location: LSIA hangar area. You can move it with F9 anytime.

Build Requirements
------------------
- Visual Studio **Build Tools 2022** (C++ workload)
- **ScriptHookV SDK** by Alexander Blade
  - Put the SDK files like this:
        sdk\inc\script.h
        sdk\inc\keyboard.h
        sdk\lib\ScriptHookV.lib
  - (From the ScriptHookV SDK download)

How to Build
------------
1) Place the SDK headers and lib into the `sdk\` folder as shown above.
2) Double-click `tools\Build.bat`. It uses MSBuild to build Release x64.
3) The output ASI will be at:
       ShowroomWarehouse_ASI\bin\Release\ShowroomWarehouse_ASI.asi
   and copied to:
       OpenIV\content\root\ShowroomWarehouse.asi

Install with OpenIV (.OIV)
--------------------------
1) Open PowerShell in this folder and run:
       Compress-Archive -Path OpenIV\content -DestinationPath ShowroomWarehouse.oiv -Force
2) Drag `ShowroomWarehouse.oiv` into OpenIV. It will place `ShowroomWarehouse.asi` in the GTA V root.

Manual Install
--------------
Copy `ShowroomWarehouse_ASI.asi` into your GTA V root (where GTAV.exe is).
Make sure ScriptHookV (dinput8.dll + ScriptHookV.dll) is in the root as well.

Save Files
----------
- Origin & cars are saved under the GTA root:
    scripts\ShowroomWarehouse\Origin_ASI.txt
    scripts\ShowroomWarehouse\ShowroomCars_ASI.txt
