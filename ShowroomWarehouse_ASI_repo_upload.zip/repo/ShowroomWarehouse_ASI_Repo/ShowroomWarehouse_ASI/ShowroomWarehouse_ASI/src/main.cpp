
#include <windows.h>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>
#include "script.h"
#include "keyboard.h"

// ---- Config ----
static Vector3 DEFAULT_ORIGIN = { -1267.0f, -3013.0f, 13.94f };
static float DEFAULT_HEADING = 330.0f;
static float ZONE_RADIUS = 38.0f;

static std::string DataDir()
{
    char modulePath[MAX_PATH] = {0};
    GetModuleFileNameA(GetModuleHandleA(NULL), modulePath, MAX_PATH);
    std::string root(modulePath);
    auto pos = root.find_last_of("\\/");
    root = root.substr(0, pos + 1);
    return root + "scripts\\ShowroomWarehouse\\";
}

static std::string CarsFile()   { return DataDir() + "ShowroomCars_ASI.txt"; }
static std::string OriginFile() { return DataDir() + "Origin_ASI.txt"; }

struct ShowCar {
    Hash model;
    Vector3 pos;
    float heading;
    std::string plate;
};

static Vector3 g_origin = DEFAULT_ORIGIN;
static float g_heading = DEFAULT_HEADING;
static bool g_visible = true;
static Blip g_blip = 0;
static std::vector<Vehicle> g_spawned;
static std::vector<ShowCar> g_cars;

static void notify(const std::string& msg)
{
    UI::BEGIN_TEXT_COMMAND_PRINT("STRING");
    UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)msg.c_str());
    UI::END_TEXT_COMMAND_PRINT(2000, true);
}

static void ensure_dir()
{
    CreateDirectoryA(DataDir().c_str(), NULL);
}

static void save_origin()
{
    ensure_dir();
    std::ofstream f(OriginFile());
    f << g_origin.x << "," << g_origin.y << "," << g_origin.z << "|" << g_heading;
}

static void load_origin()
{
    std::ifstream f(OriginFile());
    if (!f.good()) { g_origin = DEFAULT_ORIGIN; g_heading = DEFAULT_HEADING; return; }
    std::string line; std::getline(f, line);
    auto pipe = line.find('|');
    auto xyz = line.substr(0, pipe);
    auto hstr = line.substr(pipe+1);
    float x,y,z,h;
    sscanf(xyz.c_str(), "%f,%f,%f", &x,&y,&z);
    sscanf(hstr.c_str(), "%f", &h);
    g_origin = {x,y,z}; g_heading = h;
}

static void save_cars()
{
    ensure_dir();
    std::ofstream f(CarsFile());
    for (auto& c : g_cars)
    {
        f << std::hex << c.model << std::dec << "|"
          << c.pos.x << "," << c.pos.y << "," << c.pos.z << "|"
          << c.heading << "|" << c.plate << "\n";
    }
}

static void load_cars()
{
    g_cars.clear();
    std::ifstream f(CarsFile());
    if (!f.good()) return;
    std::string line;
    while (std::getline(f, line))
    {
        ShowCar c{};
        auto p1 = line.find('|');
        auto p2 = line.find('|', p1+1);
        auto p3 = line.find('|', p2+1);
        std::string modelHex = line.substr(0, p1);
        std::stringstream ss; ss << std::hex << modelHex; ss >> c.model;
        sscanf(line.substr(p1+1, p2-p1-1).c_str(), "%f,%f,%f", &c.pos.x, &c.pos.y, &c.pos.z);
        sscanf(line.substr(p2+1, p3-p2-1).c_str(), "%f", &c.heading);
        c.plate = line.substr(p3+1);
        g_cars.push_back(c);
    }
}

static void draw_zone_markers()
{
    for (int i=0;i<36;i++)
    {
        float a = (i/36.0f) * (float)(3.1415926 * 2.0);
        Vector3 pt = { g_origin.x + cosf(a)*ZONE_RADIUS, g_origin.y + sinf(a)*ZONE_RADIUS, g_origin.z + 0.05f };
        GRAPHICS::DRAW_MARKER(1, pt.x, pt.y, pt.z, 0,0,0, 0,0,0, 0.3f,0.3f,0.3f, 120,200,255, 100, false, true, 2, false, 0, 0, false);
    }
    Vector3 fwd = { -sinf(g_heading * 3.1415926f/180.0f), cosf(g_heading * 3.1415926f/180.0f), 0 };
    Vector3 entry = { g_origin.x - fwd.x*ZONE_RADIUS, g_origin.y - fwd.y*ZONE_RADIUS, g_origin.z + 1.4f };
    GRAPHICS::DRAW_MARKER(21, entry.x, entry.y, entry.z, 0,0,0, 0,0,0, 1.0f,1.0f,1.0f, 255,255,255,200, false, true, 2, false, 0, 0, false);
}

static void maintain_lights()
{
    for (int r=1; r<=3; ++r)
    {
        float rad = (ZONE_RADIUS/(3+1))*r;
        int points = 10 + r*4;
        for (int i=0;i<points;i++)
        {
            float ang = (i/(float)points) * (float)(3.1415926*2.0);
            Vector3 pos = { g_origin.x + cosf(ang)*rad, g_origin.y + sinf(ang)*rad, g_origin.z + 5.8f };
            GRAPHICS::DRAW_LIGHT_WITH_RANGE(pos.x,pos.y,pos.z, 255,255,255, 16.0f, 2.0f);
        }
    }
    GRAPHICS::DRAW_LIGHT_WITH_RANGE(g_origin.x, g_origin.y, g_origin.z + 6.2f, 255,255,255, 22.0f, 2.0f);
}

static void respawn_all()
{
    for (auto v : g_spawned) { if (ENTITY::DOES_ENTITY_EXIST(v)) VEHICLE::DELETE_VEHICLE(&v); }
    g_spawned.clear();

    for (auto& sc : g_cars)
    {
        if (!STREAMING::IS_MODEL_IN_CDIMAGE(sc.model) || !STREAMING::IS_MODEL_A_VEHICLE(sc.model)) continue;
        STREAMING::REQUEST_MODEL(sc.model);
        while (!STREAMING::HAS_MODEL_LOADED(sc.model)) WAIT(0);
        Vehicle v = VEHICLE::CREATE_VEHICLE(sc.model, sc.pos.x, sc.pos.y, sc.pos.z, sc.heading, true, false);
        STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(sc.model);
        if (ENTITY::DOES_ENTITY_EXIST(v))
        {
            VEHICLE::SET_VEHICLE_FIXED(v);
            VEHICLE::SET_VEHICLE_DIRT_LEVEL(v, 0.0f);
            VEHICLE::SET_VEHICLE_ENGINE_ON(v, true, true, false);
            VEHICLE::SET_VEHICLE_LIGHTS(v, 3);
            if (!sc.plate.empty()) VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(v, (char*)sc.plate.c_str());
            g_spawned.push_back(v);
        }
    }
}

static Vehicle nearest_vehicle(Vector3 pos, float range)
{
    Vehicle best = 0; float bestDist = range;
    int count = worldGetAllVehicles(nullptr, 0);
    std::vector<Vehicle> arr(count);
    worldGetAllVehicles(arr.data(), count);
    for (auto v : arr)
    {
        if (!ENTITY::DOES_ENTITY_EXIST(v)) continue;
        Vector3 p = ENTITY::GET_ENTITY_COORDS(v, true);
        float d = SYSTEM::VDIST(p.x, p.y, p.z, pos.x, pos.y, pos.z);
        if (d < bestDist) { best = v; bestDist = d; }
    }
    return best;
}

static void try_save_nearest()
{
    Ped ped = PLAYER::PLAYER_PED_ID();
    Vector3 ppos = ENTITY::GET_ENTITY_COORDS(ped, true);
    float dcenter = SYSTEM::VDIST2(ppos.x, ppos.y, ppos.z, g_origin.x, g_origin.y, g_origin.z);
    if (sqrtf(dcenter) > ZONE_RADIUS + (PED::IS_PED_IN_ANY_VEHICLE(ped, false) ? 6.0f : 3.0f))
    {
        notify("Step/drive inside the showroom circle to save a car.");
        return;
    }

    Vehicle v = PED::IS_PED_IN_ANY_VEHICLE(ped, false) ? PED::GET_VEHICLE_PED_IS_USING(ped) : nearest_vehicle(ppos, 6.0f);
    if (!ENTITY::DOES_ENTITY_EXIST(v)) { notify("No vehicle nearby to save."); return; }

    Vector3 vpos = ENTITY::GET_ENTITY_COORDS(v, true);
    float d2 = SYSTEM::VDIST2(vpos.x, vpos.y, vpos.z, g_origin.x, g_origin.y, g_origin.z);
    if (sqrtf(d2) > ZONE_RADIUS) { notify("Vehicle must be fully inside the showroom."); return; }

    ShowCar sc{};
    sc.model = ENTITY::GET_ENTITY_MODEL(v);
    sc.pos = vpos;
    sc.heading = ENTITY::GET_ENTITY_HEADING(v);
    sc.plate = VEHICLE::GET_VEHICLE_NUMBER_PLATE_TEXT(v);

    // Update if same model+plate, else push
    int idx = -1;
    for (int i=0;i<(int)g_cars.size();++i)
    {
        if (g_cars[i].model == sc.model && g_cars[i].plate == sc.plate) { idx = i; break; }
    }
    if (idx >= 0) g_cars[idx] = sc; else g_cars.push_back(sc);

    save_cars();
    respawn_all();
    notify("Saved/updated car in showroom.");
}

static void try_remove_nearest()
{
    Ped ped = PLAYER::PLAYER_PED_ID();
    Vector3 p = ENTITY::GET_ENTITY_COORDS(ped, true);

    Vehicle best = 0; float bestDist = 5.0f;
    for (auto v : g_spawned)
    {
        if (!ENTITY::DOES_ENTITY_EXIST(v)) continue;
        Vector3 vp = ENTITY::GET_ENTITY_COORDS(v, true);
        float d = SYSTEM::VDIST(p.x,p.y,p.z, vp.x,vp.y,vp.z);
        if (d < bestDist) { best = v; bestDist = d; }
    }
    if (!best) { notify("No saved car in reach."); return; }

    std::string plate = VEHICLE::GET_VEHICLE_NUMBER_PLATE_TEXT(best);
    Hash model = ENTITY::GET_ENTITY_MODEL(best);

    for (auto it = g_cars.begin(); it != g_cars.end(); ++it)
    {
        if (it->model == model && it->plate == plate)
        {
            g_cars.erase(it);
            break;
        }
    }
    save_cars();
    respawn_all();
    notify("Removed car from showroom.");
}

static void build_environment()
{
    if (UI::DOES_BLIP_EXIST(g_blip)) UI::REMOVE_BLIP(&g_blip);
    g_blip = UI::ADD_BLIP_FOR_COORD(g_origin.x, g_origin.y, g_origin.z);
    UI::SET_BLIP_SPRITE(g_blip, 50); // garage
    UI::SET_BLIP_COLOUR(g_blip, 3);
    UI::SET_BLIP_SCALE(g_blip, 0.9f);
    UI::BEGIN_TEXT_COMMAND_SET_BLIP_NAME("STRING");
    UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("Showroom Warehouse");
    UI::END_TEXT_COMMAND_SET_BLIP_NAME(g_blip);
}

static void toggle_visible()
{
    g_visible = !g_visible;
    if (g_visible) { build_environment(); respawn_all(); }
    else {
        for (auto v : g_spawned) { if (ENTITY::DOES_ENTITY_EXIST(v)) VEHICLE::DELETE_VEHICLE(&v); }
        g_spawned.clear();
        if (UI::DOES_BLIP_EXIST(g_blip)) UI::REMOVE_BLIP(&g_blip);
    }
    notify(g_visible ? "Warehouse: VISIBLE" : "Warehouse: HIDDEN");
}

void main()
{
    ensure_dir();
    load_origin();
    load_cars();
    build_environment();
    respawn_all();
    notify("ASI Showroom loaded. F10 toggle • E save • DEL remove • F9 move");

    while (true)
    {
        if (IsKeyJustUp(VK_F10)) toggle_visible();
        if (IsKeyJustUp(VK_F9)) {
            Ped ped = PLAYER::PLAYER_PED_ID();
            g_origin = ENTITY::GET_ENTITY_COORDS(ped, true);
            g_heading = ENTITY::GET_ENTITY_HEADING(ped);
            save_origin();
            build_environment();
            respawn_all();
            notify("Warehouse moved here.");
        }
        if (IsKeyJustUp(0x45)) { try_save_nearest(); } // E
        if (IsKeyJustUp(VK_DELETE)) { try_remove_nearest(); }

        if (g_visible) {
            draw_zone_markers();
            maintain_lights();
        }

        WAIT(0);
    }
}

void ScriptMain()
{
    srand(GetTickCount());
    main();
}
